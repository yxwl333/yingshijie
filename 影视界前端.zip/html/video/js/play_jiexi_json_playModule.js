var touping;
var deviceIndex;
var acc5Util; //音量处理
var uzmoduledemo;
var Out_Time = 10000;
var Second_Out_Time = Out_Time / 1000;
var touping_video = null;
var xuan_url = '';
var getxuan;
var deviceIp;
var deviceLists;
var isxuan = 0;
var xuan_count = 0;
var playModule; //乐檬新module播放器

//定时检测音量
var interval = setInterval(function() {
    VolumeInspect(1);
}, 3000);

apiready = function() {

        if (localStorage.getItem('is_play_change') == 0) {
            $api.byId('Mobile_player1').innerHTML = '';
        }
        playModule = api.require('playModule');
        acc5Util = api.require('acc5Util');
        h = api.frameHeight;
        w = api.frameWidth;
        xuan_url = api.pageParam.beginurl;
        console.log(xuan_url)
        api.parseTapmode();
        openplay_playModule(); //播放器
        // GoJiexi('https://jx.parwix.com:4433/player/?url=https://v.qq.com/x/cover/mzc00200y323aub.html', '默认线路');
        // return;
        GoJiexi(api.pageParam.url, '默认线路');
        lmbrowse(); // 乐檬选集
        ad_img(); //乐檬广告
        setTimeout(function() { //延迟执行
            //上传播放记录
            U.Up_Play_Record(api.pageParam.beginurl, api.pageParam.title);
        }, 10000);

        api.setScreenOrientation({
            orientation: 'portrait_up'
        });

        //监听播放状态
        playModule.addEventListener({
            name: 'playError'
        }, function(ret, err) {
            U.toast('当前线路资源可能无法播放 请切换！');
            showTips('当前线路资源可能无法播放 请切换！ ', 10000, '', '', 10000, 1, '当前线路资源可能无法播放 请切换！', 10000, 1); //不关闭 只警告
        });

        playModule.addEventListener({
            name: 'bufferingStart'
        }, function(ret, err) {
            console.log("缓冲开始>>>>" + JSON.stringify(ret));
        });
        playModule.addEventListener({
            name: 'bufferingEnd'
        }, function(ret, err) {
            console.log("缓冲结束>>>>" + JSON.stringify(ret));
        });
        playModule.addEventListener({
            name: 'onPrepared'
        }, function(ret, err) {
            console.log("视频准备完成>>>>" + JSON.stringify(ret));
        });



        mute_state.innerHTML = api.pageParam.cutlineNmae;
        U.toast('正在努力为您获取资源 请稍等···');
        api.addEventListener({
            name: 'keyback'
        }, function(ret, err) {
            goback();
        });
        //换线
        api.addEventListener({
            name: 'cutline'
        }, function(ret, err) {
            var cutlineNmae = ret.value['cutlineNmae'];
            showTips('正在为您切换线路： ' + cutlineNmae + '请稍等···', 5000, 1, '', 10000, 1, '如 ' + cutlineNmae + ' 无播放资源将维持当前播放线路', 3000, 1); //警告 并 关闭
            //先关闭解析窗口
            CloseResolutionBrowser();
            GoJiexi(ret.value['url'], cutlineNmae);
        });

        //离开页面时暂停播放
        api.addEventListener({
            name: 'viewdisappear'
        }, function() {
            playModule.pause();
            goback();
        });
        //监听左上角返回
        api.addEventListener({
            name: 'goback'
        }, function() {
            playModule.pause();
            goback();
        });
        //监听重新获取
        api.addEventListener({
            name: 'Exit_full_screen'
        }, function(ret, err) {
            if (ret) {
                goback();
            }
        });
        // 乐檬监听返回
        api.addEventListener({
            name: 'keyback'
        }, function(ret, err) {
            GoBack();
        });
        showTips('影片中的文字广告请勿相信，谨防上当受骗！', 10000, 1, '', 10000, 1, '影片中的文字广告请勿相信，谨防上当受骗！', 10000, 1); //警告 并 关闭
        /****事件检测****/
        api.addEventListener({
            name: 'pause'
        }, function(ret, err) {
            U.toast('应用已进入后台运行');
            playModule.pause();
        });
        api.addEventListener({
            name: 'resume'
        }, function(ret, err) {
            U.toast('正在为您恢复播放')
            playModule.start();
        });
    }
    // 乐檬广告
function ad_img() {
    var play_ad_img = localStorage.getItem('play_ad_img');
    if (play_ad_img != '') {
        list_img = '<img  onclick="ad_open(' + '\'' + localStorage.getItem('play_ad_url') + '\'' + ')" src="' + play_ad_img + '" alt="">'
        $api.byId('ad_img').innerHTML = list_img;
    }
}

function ad_open(text) {
    console.log(text);
    if (text == '' || text == null || !text) {
        return;
    } else if (text.indexOf("http") != -1) {
        var browser = api.require('webBrowser');
        browser.open({
            url: text
        })
        return;
    } else if (text == '代理介绍') {
        U.openWin('agent/', 'agent_introduction')
        return;
    } else {
        U.openWin(text, '')
        return;
    }

}
//乐檬选集
function lmbrowse() {
    console.log('开始加载选集：' + localStorage.getItem('api_url') + '/app/Lemon/?url=' + api.pageParam.beginurl);
    console.log(xuan_count);;
    api.ajax({
        url: localStorage.getItem('api_url') + '/app/Lemon/',
        method: 'get',
        data: {
            values: {
                url: api.pageParam.beginurl,
            }
        }
    }, function(ret, err) {
        getxuan = ret;
        console.log(JSON.stringify(getxuan))
        try {
            if (getxuan.code != 0) {
                console.log('接收到返回参数');
                var HTML = '';
                console.log('选集数量');
                if (getxuan.msg.length > 0) {
                    console.log('准备循环读取选集');
                    for (var i = 0; i < getxuan.msg.length; i++) {
                        var s = i + 1;
                        HTML += '<a  onclick="xuanji(' + '\'' + getxuan.msg[i].url + '\'' + ',' + s + ')" id="' + s + '" class="aui-palace-grid" style="background-color: #1b7dff;margin: 10px 2.5% 0 2.5%;"><div class="aui-palace-grid-text"><h2 style="color: #fff;">' + getxuan.msg[i].title + '</h2></div></a>';
                        isxuan = 1;
                    }
                    console.log('开始渲染');
                    var obj = document.getElementById("xuanji_title");
                    obj.setAttribute("class", 'aui-title display-block');
                    $api.byId('xuan_html_list_frm').innerHTML = HTML;
                    console.log('渲染结束');
                }
            }
        } catch (err) {
            console.log(err);
            if (isxuan == 0 && xuan_count > 5) {
                xuan_count++;
                console.log('再次加载选集第' + xuan_count + '次')
                lmbrowse()
            }
        }

    });
}
//加载结束
//乐檬选集
function xuanji(url, id) {
    var HTML = '';
    for (var i = 0; i < getxuan.msg.length; i++) {
        var s = i + 1;
        HTML += '<a  onclick="xuanji(' + '\'' + getxuan.msg[i].url + '\'' + ',' + s + ')" id="' + s + '" class="aui-palace-grid" style="background-color: #1b7dff;margin: 10px 2.5% 0 2.5%;"><div class="aui-palace-grid-text"><h2 style="color: #fff;">' + getxuan.msg[i].title + '</h2></div></a>';
    }
    $api.byId('xuan_html_list_frm').innerHTML = HTML;
    var ids = document.getElementById(id);
    ids.style.backgroundColor = "#0450b5";
    api.toast({
        msg: '正在切换第' + id + '集请稍等',
        global: true
    });
    xuan_url = url;
    console.log(xuan_url)
    GoJiexi(localStorage.getItem('jx_Interface_one') + xuan_url, '选集播放');
}


// 乐檬解析
function GoJiexi(url, line) {

    if (url.indexOf("...") != -1) {
        url = url["replace"]("...", ".");
        console.log("解析了1..." + url);
        // GoJiexi_Json(jiekou1, line, true);
    }

    if (url.indexOf("..") != -1) {
        url = url["replace"]("..", ".");
        console.log("解析了2.." + url);
        // GoJiexi_Json(jiekou1, line, false);
    }

    var jiexigo = 0;
    arr = url.split('http');
    console.log(JSON.stringify(arr));
    for (var i = 0; i < arr.length; i++) {
        if (arr[i].indexOf("m3u8") != -1 || arr[i].indexOf("mp4") != -1) {
            video_url = 'http' + arr[i];
            touping_video = video_url;
            jiexigo = 1;
        }
    }
    if (jiexigo == 1) {
        console.log('直链播放' + video_url)
        goplay_playModule(video_url)
        return;
    }

    api.ajax({
        url: url,
        method: 'get',
    }, function(ret, err) {
        console.log(JSON.stringify(ret))
        if (ret.code) {
            console.log('json播放：' + url)
            if (ret.code != 200) {
                U.toast(line + ' 资源获取失败 请切换线路');
                return;
            }
            U.toast(line + ' 资源获取成功 准备播放');
            console.log(line + ' 资源获取成功 准备播放')
            goplay_playModule(ret.url)
            console.log('JSON资源获取成功' + ret.url);
        } else {
            console.log('解析播放：' + url)
            uzmoduledemo = api.require('androidBrowser');
            uzmoduledemo.closeView();
            var param = {
                rect: {
                    x: 0,
                    y: 80,
                    w: 'auto',
                    h: 250
                },
                fixedOn: "", //浏览器依附在哪个window,不传或传空 为 当前Window，默认当前当前Window
                fixed: true, //浏览器是否随frame或Window滑动，默认当前当前true
                url: url, //要加载的url,可选项
                browserBg: "#F0F0F0", //可选
                timeout: 7, //超时时间,指加载页面完毕后等待多少秒，超过这个时间还没收到视频地址，则认为解析视频地址失败。默认7秒
            };
            uzmoduledemo.openView(param, function(ret, err) {
                if (ret.result == '1') {
                    uzmoduledemo.closeView();
                    video_url = ret.VideoUrl;
                    U.toast(line + ' 资源获取成功 准备播放');
                    console.log('解析资源获取成功' + video_url)
                    mute_state.innerHTML = line;
                    touping_video = video_url;
                    goplay_playModule(video_url)
                }
            });
        }
    });
}


function viodeplay() {
    GoJiexiH5(localStorage.getItem('jx_Interface_one') + xuan_url, '系统播放器');
}

function GoJiexiH5(url, line) {
    U.toast(' 正在调用系统播放器打开视频');
    //打开系统视频播放器
    api.openVideo({
        url: touping_video
    });

}



function goback() {
    playModule.isFullScreen(function(ret, err) {
        if (ret.status) {
            playModule.unfull(function(ret, err) {});
        } else {
            api.closeWin()
        }
    });
}

// 打开播放器播放
function openplay_playModule() {
    playModule.init({
        logo: "widget://images/b_03.png.png",
    });

    playModule.play({
        rect: {
            x: 0,
            y: 0,
            w: 'auto',
            h: 250
        },
        fixedOn: api.frameName,
        fixed: true,
        title: "正在加载中",
        url: 'https://vkceyugu.cdn.bspapp.com/VKCEYUGU-a64ba7db-3cc1-47f2-a4a7-7ab09d13373b/7bfb1bc8-b091-4fa3-aedc-7d05fee2e753.mp4',
        defaultBtn: false,
        enableFull: false,
        isLocalCache: true,
    }, function(ret, err) {
        //alert(JSON.stringify(ret));
    });
}



// 开始播放
function goplay_playModule(url) {
    playModule.playUrl({
        defaultBtn: true,
        title: api.pageParam.title,
        url: url,
        //process : 302334,
        isLive: false, //是否直播视频源 (直播：true；点播：false)
        isOpenGesture: true, //是否开启手势控制音量，亮度和进度，默认开启手势控制，true为开启false为关闭
        isPlayMusic: false, //是否仅播放音频 (仅播放音频:true ; 视频播放:false)
        isAutoPlay: true, //是否自动播放 (自动播放:true ; 不自动播放:false)
        isLoop: false, //是否循环播放 (循环播放:true ; 禁止循环播放:false)
        urlDatas: false, //清晰度按钮的自定义(数组内容大于1条记录，清晰度切换按钮才会显示，不支持直播链接的组装切换，不能和url接口参数同时存在)。
        isMute: false, //是否静音播放 (开启静音:true ; 关闭静音:false)
        isShowDanmu: true, //是否开启弹幕功能 (开启:true ; 不开启:false)
        isLocalCache: false, //是否本地缓存视频,音频;直播类不能缓存,开发者自行控制;(备注:缓存文件在cache://文件目录下,如果直播乱开启改参数会导致播放异常). (开启:true ; 不开启:false)
        isShowFenxiang: true, //全屏是否显示分享按钮 (显示:true ; 隐藏:false)
        isShowMore: true, //全屏是否显示更多按钮 (显示:true ; 隐藏:false)
        isShowTouping: true, //全屏是否显示投屏按钮 (显示:true ; 隐藏:false)
        isShowXuanji: false, //是否显示选集按钮 (显示:true ; 隐藏:false)
        isShowNext: false, //是否显示下一集按钮 (显示:true ; 隐藏:false)
        isShowPre: false, //是否显示上一集按钮 (显示:true ; 隐藏:false)
        isSmallImmerse: true, //窗口播放顶部控制栏是否沉侵式 (显示:true ; 隐藏:false)
        isLongShowBackBtn: false, //窗口模式下是否长时间显示返回按钮 (显示:true ; 隐藏:false)
        isSmallShowFenxiang: false, //窗口是否显示分享按钮 (显示:true ; 隐藏:false)
        isSmallShowMore: false, //窗口是否显示更多按钮 (显示:true ; 隐藏:false)
        isSmallShowTouping: true, //窗口是否显示投屏按钮 (显示:true ; 隐藏:false)
        isOpenDanmu: false, //是否打开弹幕功能 (打开:true ; 关闭:false)
        isShowNetworkSpeed: true, //是否在缓冲的时候显示网速
        freeProcess: false, //设置可免费播放时长,当免费播放完后触发播放异常事件，错误码5721
        scalingMode: 1, //1 无缩放 2 适应大小模式 3 充满可视范围，可能会被裁剪 4 缩放到充满视图
        fullscreenMode: 'LANDSCAPE', //设置全屏按钮控制全屏显示模式是横屏还是竖屏 竖屏:PORTRAIT ; 横屏:LANDSCAPE
        isShowProcessView: true, //是否显示进度条 (显示:true ; 不显示:false)
        isShowTimeLable: true, //是否显示播放时间 显示:true ; 不显示:false
        defaultSpeed: {
            name: 'X1.0',
            speed: 1.0
        },
        speedDatas: [{
            name: 'X0.5',
            speed: 0.5
        }, {
            name: 'X1.0',
            speed: 1.0
        }, {
            name: 'X1.5',
            speed: 1.5
        }, {
            name: 'X2.0',
            speed: 2.0
        }, {
            name: 'X4.0',
            speed: 4.0
        }],
    }, function(ret, err) {
        //alert(JSON.stringify(ret));
    });
}






//按钮事件
function ButtonEvent(name) {
    //分享
    if (name == 'Share') {
        U.openWin('share/', 'share');
    }

    //H5播放器
    if (name == 'h5_paly') {
        console.log(xuan_url)
        U.openWin('browser/', 'webx5_jx_play_h5', {
            url: localStorage.getItem('jx_Interface_one') + xuan_url,
            primary_url: xuan_url,
            title: api.pageParam.title,
            cutlineNmae: '当前:默认线路'
        }, '');
        api.closeWin();
    }
    //投屏
    if (name == 'Touping') {
        U.OpenTouPingPopup(touping_video, api.pageParam.title);

    }




}




/*音量检测*/
//type  1、提示    operation  操作



function VolumeInspect(type, operation) {

    //acc5Util 模块检测
    acc5Util.getVol({}, function(ret, err) {
        //  alert(JSON.stringify(ret.data['music']));

        //静音
        if (ret.data['music'] == 0) {

            if (type == 1) {

                mute_state.innerHTML = '手机可能处于静音状态';

                var obj = document.getElementById("mute_state");
                obj.setAttribute("class", 'aui-live-icon-em-mute');

                mute_state_touping.innerHTML = ' 手机静音中 停止后恢复';

                var obj = document.getElementById("mute_state_touping");
                obj.setAttribute("class", 'aui-live-icon-em-mute');



            }


            if (operation == 1) {

                //如果选择 自动调整音量
                if (localStorage.getItem('automatic_volume') == 1) {

                    acc5Util.setVol({
                        value: localStorage.getItem('default_player_volume')
                    }, function(ret, err) {})

                }

            }
        } else {


            //	mute_state.innerHTML = '开始追剧吧！';

            var obj = document.getElementById("mute_state");
            obj.setAttribute("class", 'aui-live-icon-em');


            mute_state_touping.innerHTML = ' 投屏时建议静音 ';

            var obj = document.getElementById("mute_state_touping");
            obj.setAttribute("class", 'aui-live-icon-em-mute-one');


        }
    })

}




/*** showTips提示方法 ***/
// 进行提示	showTips(提示消息,延迟时间, 1 关闭 空跳过,关闭后的消息,关闭延迟,1 警告 空跳过,警告消息,警告延迟,类型);
function showTips(msg, Timeout, isClose, CloseMsg, CloseTimeout, isWarning, WarningMsg, WarningTimeout, type) {

    if (type == 1) { // 视频提示信息

        var obj = document.getElementById("video_tip");
        obj.setAttribute("class", 'aui-live-header-black');
        video_tip.innerHTML = '<span style="font-size:12px;">' + msg + '</span>';

        //是否需要关闭
        //关闭 且 警告
        if (isClose == 1 && isWarning == 1) {

            setTimeout(function() { //延迟执行 警告

                var obj = document.getElementById("video_tip");
                obj.setAttribute("class", 'aui-live-header-warning');

                video_tip.innerHTML = '<span style="font-size:12px;">' + WarningMsg + '</span>'; //警告信息

                // setTimeout("closeTips()", WarningTimeout);  //延迟执行 关闭提示

                setTimeout(function() { //延迟执行 关闭

                    var obj = document.getElementById("video_tip");
                    obj.setAttribute("class", 'aui-live-header-close');

                    video_tip.innerHTML = '<span style="font-size:12px;">' + CloseMsg + '</span>'; //关闭后的信息

                }, CloseTimeout);

            }, WarningTimeout);



            //不关闭  但警告
        } else if (isWarning == 1) {

            setTimeout(function() { //延迟执行

                var obj = document.getElementById("video_tip");
                obj.setAttribute("class", 'aui-live-header-warning');

                video_tip.innerHTML = '<span style="font-size:12px;">' + WarningMsg + '</span>'; //警告信息

            }, Timeout);


            // 直接关闭 不警告
        } else if (isClose == 1) {

            setTimeout(function() { //延迟执行
                var obj = document.getElementById("video_tip");
                obj.setAttribute("class", 'aui-live-header-close');

                video_tip.innerHTML = '<span style="font-size:12px;">' + CloseMsg + '</span>'; //关闭后的信息

                //		video_operation_tip.innerHTML = '点击查看';

            }, Timeout);
        }
    } else if (type == 2) { // 投屏提示信息 Touping_tip
        var obj = document.getElementById("Touping_tip");
        obj.setAttribute("class", 'aui-live-touping-black');
        Touping_tip.innerHTML = '<span style="font-size:12px;">' + msg + '</span>';
        //是否需要关闭
        //关闭 且 警告
        if (isClose == 1 && isWarning == 1) {
            setTimeout(function() { //延迟执行 警告
                var obj = document.getElementById("Touping_tip");
                obj.setAttribute("class", 'aui-live-touping-warning');
                Touping_tip.innerHTML = '<span style="font-size:12px;">' + WarningMsg + '</span>'; //警告信息
                setTimeout(function() { //延迟执行 关闭
                    var obj = document.getElementById("Touping_tip");
                    obj.setAttribute("class", 'aui-live-touping-close');
                    Touping_tip.innerHTML = '<span style="font-size:12px;">' + CloseMsg + '</span>'; //关闭后的信息
                }, CloseTimeout);
            }, WarningTimeout);

            //不关闭  但警告
        } else if (isWarning == 1) {
            setTimeout(function() { //延迟执行
                var obj = document.getElementById("Touping_tip");
                obj.setAttribute("class", 'aui-live-touping-warning');
                Touping_tip.innerHTML = '<span style="font-size:12px;">' + WarningMsg + '</span>'; //警告信息
            }, Timeout);


            // 直接关闭 不警告
        } else if (isClose == 1) {

            setTimeout(function() { //延迟执行
                var obj = document.getElementById("Touping_tip");
                obj.setAttribute("class", 'aui-live-touping-close');
                Touping_tip.innerHTML = '<span style="font-size:12px;">' + CloseMsg + '</span>'; //关闭后的信息
            }, Timeout);
        }

    }

}
/*** showTips提示方法 ***/


//关闭解析浏览器
function CloseResolutionBrowser() {
    uzmoduledemo = api.require('androidBrowser');
    uzmoduledemo.closeView();
}


//换线
//关掉当前页面返回  X5
function OpenVideoJxPopup() {
    playModule.pause();
    U.OpenVideoJxAndroidPopup(xuan_url, api.pageParam.title, 1);
}



/*** 循环执行方法 ***/
// name   time   参数
function Recycling(name, time, param) {
    //定时检测音量
    var Task_number = name;
    var Task_number = setInterval(function() {
        eval(name + '("' + param + '");');
    }, time);

}
/*** 循环执行方法 ***/