
var ox;
var uzmoduledemo;
var play_url = '';	//默认组合URL
var play_title = '';
var begin_url = '';	//原URL
var xuan_url = '';


apiready = function () {
    xuan_url = api.pageParam.beginurl;
    xuan_url = 'https://v.qq.com/x/cover/mzc00200c0cgfxj.html';
    console.log(xuan_url)

    uzmoduledemo = api.require('androidBrowser');
    ox = api.require('oxPlayer');

    //休眠
    api.setKeepScreenOn({
        keepOn: true
    });

    play_url = api.pageParam.url;		//获取传递值；
    begin_url = api.pageParam.beginurl;		//获取传递值；
    play_title = api.pageParam.title;		//获取传递值；

    GoJiexi(play_url, '默认线路');
    U.toast('正在努力为您获取资源 请稍等···');


    api.addEventListener({
        name: 'goback'
    }, function (ret, err) {
        goback();
    });
    GoJiexi(xuan_url)
}
function goback() {
    ox.remove();
    api.closeWin();
}

function GoJiexi(url, line) {
    //	alert(JSON.stringify(url));  
    var param = {
        rect: {
            x: 0,
            y: 0,
            w: 1,
            h: 1,
        }, //w,h等于0代表横向满屏和纵向满屏
        fixedOn: "", //浏览器依附在哪个window,不传或传空 为 当前Window，默认当前当前Window
        fixed: true, //浏览器是否随frame或Window滑动，默认当前当前true
        url: url, //要加载的url,可选项
        browserBg: "#F0F0F0", //可选
        timeout: 7, //超时时间,指加载页面完毕后等待多少秒，超过这个时间还没收到视频地址，则认为解析视频地址失败。默认7秒

    };
    uzmoduledemo.openView(param, function (ret, err) {

        console.log(JSON.stringify(ret));

        //		alert(JSON.stringify(ret));

        if (ret.result == '1') {
            video_url = ret.VideoUrl;

            //		alert(JSON.stringify('解析成功：'+video_url));
            //	goplay_dkplayer(ret.VideoUrl);
            U.toast(line + ' 资源获取成功 准备播放');
            ox.fixdPlay({
                //     icon:{isShow:false,url:icon,x:360, y:60},
                rect:{x:0, y:0,w:'auto', h:220},
                // fixedOn: 'play_oxplayer_jiexi',
                fixed: false,
                showBack: false,
                autoPlay: true,//默认false
                // ad1:{isShow:true,isShowSkip:true,url:m3u8,skipUrl:skipUrl,title:'我的广告',topBarColor:'#FFB90F'},//播放前视频广告 为空则不播放广告
                //   ad2:{isShow:true,url:ad2Url,skipUrl:skipUrl,title:'我的广告',topBarColor:'#FFB90F'},//中间暂停广告，为空则不播放广告
                index: 0,
                data: [
                    {
                        title: play_title,
                        index: '01',
                        thumb: 'https://cms-bucket.nosdn.127.net/eb411c2810f04ffa8aaafc42052b233820180418095416.jpeg',
                        url: video_url
                    }]
            }, function (ret) {
                alert(JSON.stringify(ret.code));
                if (ret.code == 0) {

                    alert(ret.msg);//返回按:小屏时返回
                }
            });

            uzmoduledemo.closeView();

        }
    });
}



/*** showTips提示方法 ***/
// 进行提示	showTips(提示消息,延迟时间, 1 关闭 空跳过,关闭后的消息,关闭延迟,1 警告 空跳过,警告消息,警告延迟,类型);
function showTips(msg, Timeout, isClose, CloseMsg, CloseTimeout, isWarning, WarningMsg, WarningTimeout, type) {

    if (type == 1) {		// 视频提示信息

        var obj = document.getElementById("video_tip");
        obj.setAttribute("class", 'aui-live-header-black');


        video_tip.innerHTML = '<span style="font-size:10px;">' + msg + '</span>';

        //有延迟时间
        /*		if(Timeout > 0){
                        setTimeout(function() {

                            api.refreshHeaderLoadDone()

                        }, Timeout);
                }else{

                }
        */


        //是否需要关闭
        //关闭 且 警告
        if (isClose == 1 && isWarning == 1) {

            setTimeout(function () {		//延迟执行 警告

                var obj = document.getElementById("video_tip");
                obj.setAttribute("class", 'aui-live-header-warning');

                video_tip.innerHTML = '<span style="font-size:10px;">' + WarningMsg + '</span>';			//警告信息

                setTimeout("closeTips()", WarningTimeout);  //延迟执行 关闭提示

                setTimeout(function () {		//延迟执行 关闭

                    var obj = document.getElementById("video_tip");
                    obj.setAttribute("class", 'aui-live-header-close');

                    video_tip.innerHTML = '<span style="font-size:10px;">' + CloseMsg + '</span>';		//关闭后的信息

                    //			video_operation_tip.innerHTML = '点击切换播放模式';

                }, CloseTimeout);

                //		video_operation_tip.innerHTML = '提示即将关闭';


            }, WarningTimeout);



            //不关闭  但警告
        } else if (isWarning == 1) {

            setTimeout(function () { 		//延迟执行

                var obj = document.getElementById("video_tip");
                obj.setAttribute("class", 'aui-live-header-warning');

                video_tip.innerHTML = '<span style="font-size:10px;">' + WarningMsg + '</span>';			//警告信息

            }, Timeout);


            // 直接关闭 不警告
        } else if (isClose == 1) {

            setTimeout(function () { 		//延迟执行
                var obj = document.getElementById("video_tip");
                obj.setAttribute("class", 'aui-live-header-close');

                video_tip.innerHTML = '<span style="font-size:10px;">' + CloseMsg + '</span>';		//关闭后的信息

                //		video_operation_tip.innerHTML = '点击查看';

            }, Timeout);
        }



    } else if (type == 2) {		// 投屏提示信息 Touping_tip



        var obj = document.getElementById("Touping_tip");
        obj.setAttribute("class", 'aui-live-touping-black');


        Touping_tip.innerHTML = '<span style="font-size:10px;">' + msg + '</span>';

        //有延迟时间
        /*		if(Timeout > 0){
                        setTimeout(function() {

                            api.refreshHeaderLoadDone()

                        }, Timeout);
                }else{

                }
        */


        //是否需要关闭
        //关闭 且 警告
        if (isClose == 1 && isWarning == 1) {

            setTimeout(function () {		//延迟执行 警告

                var obj = document.getElementById("Touping_tip");
                obj.setAttribute("class", 'aui-live-touping-warning');

                Touping_tip.innerHTML = '<span style="font-size:10px;">' + WarningMsg + '</span>';			//警告信息

                setTimeout("closeTips()", WarningTimeout);  //延迟执行 关闭提示

                setTimeout(function () {		//延迟执行 关闭

                    var obj = document.getElementById("Touping_tip");
                    obj.setAttribute("class", 'aui-live-touping-close');

                    Touping_tip.innerHTML = '<span style="font-size:10px;">' + CloseMsg + '</span>';		//关闭后的信息

                    //			video_operation_tip.innerHTML = '点击查看';

                }, CloseTimeout);

                //			video_operation_tip.innerHTML = '提示即将关闭';


            }, WarningTimeout);



            //不关闭  但警告
        } else if (isWarning == 1) {

            setTimeout(function () { 		//延迟执行

                var obj = document.getElementById("Touping_tip");
                obj.setAttribute("class", 'aui-live-touping-warning');

                Touping_tip.innerHTML = '<span style="font-size:10px;">' + WarningMsg + '</span>';			//警告信息

            }, Timeout);


            // 直接关闭 不警告
        } else if (isClose == 1) {

            setTimeout(function () { 		//延迟执行
                var obj = document.getElementById("Touping_tip");
                obj.setAttribute("class", 'aui-live-touping-close');

                Touping_tip.innerHTML = '<span style="font-size:10px;">' + CloseMsg + '</span>';		//关闭后的信息

                //			video_operation_tip.innerHTML = '点击查看';

            }, Timeout);
        }







    }

}
/*** showTips提示方法 ***/


//关闭解析浏览器
function CloseResolutionBrowser() {
    uzmoduledemo.closeView();
}


//换线
//关掉当前页面返回  X5
function OpenVideoJxPopup() {
    //  moviePlayer.pause();
    //		U.OpenVideoJxPopup(localStorage.getItem('Play_url'),0);

    U.OpenVideoJxAndroidPopup(xuan_url, api.pageParam.title, 1);
    // U.OpenVideoJxAndroidPopup(api.pageParam.beginurl, api.pageParam.title, 1);
    /*
    //广播打开 接口列表
    api.sendEvent({
        name: 'cutline',		//广播更新用户数据
        extra: {
                url:api.pageParam.url,
                type: api.pageParam.title
        }
    });


        U.closeWin('videos_play_jiexi');
*/

    //   moviePlayer.close();

    //	U.OpenVideoJxPopup(api.pageParam.initialurl);
}





/*** 循环执行方法 ***/
// name   time   参数
function Recycling(name, time, param) {
    //定时检测音量
    var Task_number = name;
    var Task_number = setInterval(function () {

        //不带参数
        //	 eval(name+'();');
        //有参
        eval(name + '("' + param + '");');

    }, time);

}
/*** 循环执行方法 ***/
