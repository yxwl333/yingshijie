var touping;
var deviceIndex;
var acc5Util; //音量处理
var dkplayer;
var uzmoduledemo;
var tinyPlayer;

var Out_Time = 10000;
var Second_Out_Time = Out_Time / 1000;
var touping_video = null;

var xuan_url = '';
var getxuan;

var deviceIp;
var deviceLists;

var isxuan = 0;
var xuan_count = 0;


//定时检测音量
var interval = setInterval(function() {
    VolumeInspect(1);
}, 3000);


PlayerProcessingLogic = ''; //播放机处理状态
DeviceConnectionStatus = ''; //设备连接状态
ToupingProgressBarTips = 1; //投屏播放进度操作提示处理状态



apiready = function() {
        tinyPlayer = api.require('tinyPlayer');
        goplay_dkplayer_open('https://vkceyugu.cdn.bspapp.com/VKCEYUGU-a64ba7db-3cc1-47f2-a4a7-7ab09d13373b/7bfb1bc8-b091-4fa3-aedc-7d05fee2e753.mp4'); //播放器
        if (localStorage.getItem('is_play_change') == 0) {
            $api.byId('Mobile_player1').innerHTML = '';
        }
        localStorage.getItem('GetTimes', 0)
        setInterval(function() { //延迟执行
            tinyPlayer.isFull(function(ret) {
                if (ret.isFull == true) {
                    api.setScreenOrientation({
                        orientation: 'landscape_left'
                    });
                    // console.log('横屏')
                } else {
                    api.setScreenOrientation({
                        orientation: 'portrait_up'
                    });
                    // console.log('切换竖屏')
                }
            });
        }, 100);



        //乐檬改乐播
        // touping = api.require('leCast');


        acc5Util = api.require('acc5Util');

        h = api.frameHeight;
        w = api.frameWidth;
        xuan_url = api.pageParam.beginurl;
        // xuan_url = 'https://v.qq.com/x/cover/mzc00200c0cgfxj.html';
        console.log(xuan_url)


        api.parseTapmode();


        GoJiexi(api.pageParam.url, '默认线路');
        setTimeout(function() { //延迟执行
            //上传播放记录
            U.Up_Play_Record(api.pageParam.beginurl, api.pageParam.title);
        }, 10000);

        api.setScreenOrientation({
            orientation: 'portrait_up'
        });

        //监听播放状态
        tinyPlayer.addEventListener(function(ret) {
            var code = ret.code;
            // console.log(code);
            if (code == 0) {
                api.closeWin();
            } else if (code == 9) {
                U.toast('当前线路资源可能无法播放 请切换！');
                showTips('当前线路资源可能无法播放 请切换！ ', 10000, '', '', 10000, 1, '当前线路资源可能无法播放 请切换！', 10000, 1); //不关闭 只警告
            }
        });
        mute_state.innerHTML = api.pageParam.cutlineNmae;
        U.toast('正在努力为您获取资源 请稍等···');
        api.addEventListener({
            name: 'keyback'
        }, function(ret, err) {
            goback();
        });
        //换线
        api.addEventListener({
            name: 'cutline'
        }, function(ret, err) {
            var cutlineNmae = ret.value['cutlineNmae'];
            showTips('正在为您切换线路： ' + cutlineNmae + '请稍等···', 5000, 1, '', 10000, 1, '如 ' + cutlineNmae + ' 无播放资源将维持当前播放线路', 3000, 1); //警告 并 关闭
            //先关闭解析窗口
            CloseResolutionBrowser();
            GoJiexi(ret.value['url'], cutlineNmae);
        });

        //离开页面时暂停播放
        api.addEventListener({
            name: 'viewdisappear'
        }, function() {
            tinyPlayer.stop();
            //  moviePlayer.pause();
            goback();
        });
        //监听左上角返回
        api.addEventListener({
            name: 'goback'
        }, function() {
            tinyPlayer.stop();
            //  moviePlayer.pause();
            goback();
        });
        //监听重新获取
        api.addEventListener({
            name: 'Exit_full_screen'
        }, function(ret, err) {
            if (ret) {
                goback();
            }
        });
        // 乐檬监听返回
        api.addEventListener({
            name: 'keyback'
        }, function(ret, err) {
            GoBack();
        });

        showTips('影片中的文字广告请勿相信，谨防上当受骗！', 10000, 1, '', 10000, 1, '影片中的文字广告请勿相信，谨防上当受骗！', 10000, 1); //警告 并 关闭


        /****事件检测****/
        api.addEventListener({
            name: 'pause'
        }, function(ret, err) {
            U.toast('应用已进入后台运行');
            tinyPlayer.stop();
        });


        api.addEventListener({
            name: 'resume'
        }, function(ret, err) {
            U.toast('正在为您恢复播放')
            tinyPlayer.start();;
        });

        lmbrowse(); // 乐檬选集
        ad_img(); //乐檬广告

    }
    // 乐檬广告
function ad_img() {
    var play_ad_img = localStorage.getItem('play_ad_img');
    if (play_ad_img != '') {
        list_img = '<img  onclick="ad_open(' + '\'' + localStorage.getItem('play_ad_url') + '\'' + ')" src="' + play_ad_img + '" alt="">'
        $api.byId('ad_img').innerHTML = list_img;
    }
}

function ad_open(text) {
    console.log(text);
    if (text == '' || text == null || !text) {
        return;
    } else if (text.indexOf("http") != -1) {
        var browser = api.require('webBrowser');
        browser.open({
            url: text
        })
        return;
    } else if (text == '代理介绍') {
        U.openWin('agent/', 'agent_introduction')
        return;
    } else {
        U.openWin(text, '')
        return;
    }

}


//乐檬选集
function lmbrowse() {
    console.log('开始加载选集');
    console.log(xuan_count);
    api.ajax({
        url: localStorage.getItem('api_url') + '/app/Lemon/',
        method: 'get',
        data: {
            values: {
                url: api.pageParam.beginurl,
            }
        }
    }, function(ret, err) {
        getxuan = ret;
        console.log(JSON.stringify(getxuan))
        try {
            if (getxuan.code != 0) {
                console.log('接收到返回参数来自：' + localStorage.getItem('api_url') + '/app/Lemon/?url=' + api.pageParam.beginurl);
                var HTML = '';
                console.log('准备循环读取选集');
                for (var i = 0; i < getxuan.msg.length; i++) {
                    var s = i + 1;
                    HTML += '<a  onclick="xuanji(' + '\'' + getxuan.msg[i].url + '\'' + ',' + s + ')" id="' + s + '" class="aui-palace-grid" style="background-color: #1b7dff;margin: 10px 2.5% 0 2.5%;"><div class="aui-palace-grid-text"><h2 style="color: #fff;">' + getxuan.msg[i].title + '</h2></div></a>';
                    isxuan = 1;
                }
                console.log('开始渲染');
                var obj = document.getElementById("xuanji_title");
                obj.setAttribute("class", 'aui-title display-block');
                $api.byId('xuan_html_list_frm').innerHTML = HTML;
                console.log('渲染结束');
            }
        } catch (err) {
            console.log(err);
            if (isxuan == 0 && xuan_count > 5) {
                xuan_count++;
                console.log('再次加载选集第' + xuan_count + '次')
                lmbrowse()
            }
        }


    });
}
//加载结束
//乐檬选集
function xuanji(url, id) {
    var HTML = '';
    for (var i = 0; i < getxuan.msg.length; i++) {
        var s = i + 1;
        HTML += '<a  onclick="xuanji(' + '\'' + getxuan.msg[i].url + '\'' + ',' + s + ')" id="' + s + '" class="aui-palace-grid" style="background-color: #1b7dff;margin: 10px 2.5% 0 2.5%;"><div class="aui-palace-grid-text"><h2 style="color: #fff;">' + getxuan.msg[i].title + '</h2></div></a>';
    }
    $api.byId('xuan_html_list_frm').innerHTML = HTML;
    var ids = document.getElementById(id);
    ids.style.backgroundColor = "#0450b5";
    api.toast({
        msg: '正在切换第' + id + '集请稍等',
        global: true
    });
    xuan_url = url;
    console.log(xuan_url)
    GoJiexi(localStorage.getItem('jx_one') + xuan_url, '选集播放');
}




function goback() {
    tinyPlayer.isLock(function(ret) {
        if (ret.code == 0) {
            if (ret.isLock) {
                api.toast({
                    msg: '请先解锁屏幕！',
                    global: true
                });
            } else {
                isFullscreen();
            }
        }
    });
}

function isFullscreen() {
    tinyPlayer.isFull(function(ret) {
        if (ret.code == 0) {
            if (ret.isFull) {
                api.setScreenOrientation({
                    orientation: 'portrait_up'
                });
                var tinyPlayers = api.require('tinyPlayer');
                tinyPlayers.exitFullScreen();
            } else {
                api.closeWin();
            }
        }
    });
}

// 乐檬解析
function GoJiexi(url, line) {

    var jiexigo = 0;
    arr = url.split('http');
    console.log(JSON.stringify(arr));
    for (var i = 0; i < arr.length; i++) {
        if (arr[i].indexOf("m3u8") != -1 || arr[i].indexOf("mp4") != -1) {
            video_url = 'http' + arr[i];
            touping_video = video_url;
            jiexigo = 1;
        }
    }
    if (jiexigo == 1) {
        mute_state.innerHTML = line;
        console.log('直链播放' + video_url)
        goplay_dkplayer(video_url)
        return;
    }

    api.ajax({
        url: url,
        method: 'get',
    }, function(ret, err) {
        console.log(JSON.stringify(ret))
        if (ret.code) {
            console.log('json播放：' + url)
            if (ret.code != 200) {
                U.toast(line + ' 资源获取失败 请切换线路');
                return;
            }
            console.log('json播放：' + ret.url)
            U.toast(line + ' 资源获取成功 准备播放');
            mute_state.innerHTML = line;
            console.log(line + ' 资源获取成功 准备播放')
            goplay_dkplayer(ret.url)
            console.log('JSON资源获取成功' + ret.url);
        } else {
            console.log('解析播放：' + url)
            uzmoduledemo = api.require('androidBrowser');
            uzmoduledemo.closeView();
            var param = {
                rect: {
                    x: 0,
                    y: 80,
                    w: 1,
                    h: 1
                },
                fixedOn: "", //浏览器依附在哪个window,不传或传空 为 当前Window，默认当前当前Window
                fixed: true, //浏览器是否随frame或Window滑动，默认当前当前true
                url: url, //要加载的url,可选项
                browserBg: "#F0F0F0", //可选
                timeout: 7, //超时时间,指加载页面完毕后等待多少秒，超过这个时间还没收到视频地址，则认为解析视频地址失败。默认7秒
            };
            uzmoduledemo.openView(param, function(ret, err) {
                if (ret.result == '1') {
                    video_url = ret.VideoUrl;
                    U.toast(line + ' 资源获取成功 准备播放');
                    console.log('解析资源获取成功' + video_url)
                    mute_state.innerHTML = line;
                    touping_video = video_url;
                    goplay_dkplayer(video_url)
                    uzmoduledemo.closeView();
                }
            });
        }
    });
}


function viodeplay() {
    GoJiexiH5(localStorage.getItem('jx_Interface_one') + xuan_url, '系统播放器');
}

function GoJiexiH5(url, line) {
    U.toast(' 正在调用系统播放器打开视频');
    //打开系统视频播放器
    api.openVideo({
        url: touping_video
    });

}


// 准备投屏	 url传入地址    num 传入集数
function goTouping() {

    // browse();
    //如果 投屏设备连接状态 已经连接
    if (DeviceConnectionStatus == 1) {
        //进行提示
        showTips('<svg t="1570042262883" class="deviceListmaincate_nav_ico" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="35759" width="64" height="64"><path d="M170.666667 682.666667h85.333333a42.666667 42.666667 0 0 1 0 85.333333H128a42.666667 42.666667 0 0 1-42.666667-42.666667V213.333333a42.666667 42.666667 0 0 1 42.666667-42.666666h768a42.666667 42.666667 0 0 1 42.666667 42.666666v512a42.666667 42.666667 0 0 1-42.666667 42.666667h-128a42.666667 42.666667 0 0 1 0-85.333333h85.333333V256H170.666667v426.666667z m243.498666 158.165333a42.666667 42.666667 0 1 1-60.330666-60.330667l128-128a42.666667 42.666667 0 0 1 60.330666 0l128 128a42.666667 42.666667 0 0 1-60.330666 60.330667L512 742.997333l-97.834667 97.834667z" p-id="35760" fill="#8f99ad"></path></svg> 正在为您投屏播放 ' + num + ' 集', 10000, '', '关闭后显示', 2000, '', '', '', 1); //警告 并 关闭
        //改变正在播放集数的样式
        //		changeNumberStatus('di'+num+'ji');
        //提交解析接口   TYPE 2 投屏
        //		gojiexi(url,2);
        //投屏

        play(api.pageParam.url);
        //如果 投屏设备连接状态 未连接
    } else {
        //进行提示
        showTips('', '', '', '', 2000, 1, '请先搜索设备并连接', 3000, 2); //不关闭 只警告
        //开始检索可用投屏设备
        browse();
    }


}


// 打开播放器播放
function goplay_dkplayer_open(url) {
    // updateAll
    tinyPlayer.showInView({
        rect: {
            x: 0,
            y: 0,
            w: 'auto',
            h: 250
        },
        fixedOn: api.frameName,
        fixed: true,
        // isLive: false,//是否直播
        forceDeviceOrientation: true, //旋转方向 true 全屏视频不旋转
        radius: 5, //圆角大小 默认 0 没有圆角
        showBack: false, //返回按钮是否显示小屏幕
        showSelect: true, //选集按钮是否显示
        showSpeed: true, //倍速按钮是否显示
        showShot: true, //截图按钮是否显示
        showBottomProcess: true,
        autoPlay: true, //默认false
        openCache: true, //是否开启缓存
        // styles: styles,//自定义控件
        hideControl: true, //是否隐藏所有控件
        backgroundHolder: '../../images/loading_wap.gif', //视频背景图片 空显示视频封面
        backgroundAlpha: 0.3, //0 背景透明度
        loop: true, //是否单急循环
        index: 0,
        data: [{
            title: api.pageParam.title,
            index: '0',
            thumb: 'https://vkceyugu.cdn.bspapp.com/VKCEYUGU-a64ba7db-3cc1-47f2-a4a7-7ab09d13373b/7746ac27-59ab-4c78-82aa-898c9b9a4c6a.gif',
            url: url
        }, ]
    });
}


// 打开播放器播放
function goplay_dkplayer(url) {
    // updateAll
    tinyPlayer.remove();
    tinyPlayer.showInView({
        rect: {
            x: 0,
            y: 0,
            w: 'auto',
            h: 250
        },
        fixedOn: api.frameName,
        fixed: true,
        // isLive: false,//是否直播
        forceDeviceOrientation: true, //旋转方向 true 全屏视频不旋转
        radius: 5, //圆角大小 默认 0 没有圆角
        showBack: false, //返回按钮是否显示小屏幕
        showSelect: true, //选集按钮是否显示
        showSpeed: true, //倍速按钮是否显示
        showShot: true, //截图按钮是否显示
        showBottomProcess: true,
        autoPlay: true, //默认false
        openCache: true, //是否开启缓存
        // styles: styles,//自定义控件
        hideControl: false, //是否隐藏所有控件
        backgroundHolder: '../../images/loading_wap.gif', //视频背景图片 空显示视频封面
        backgroundAlpha: 0.3, //0 背景透明度
        loop: false, //是否单急循环
        index: 0,
        data: [{
            title: api.pageParam.title,
            index: '0',
            thumb: 'https://vkceyugu.cdn.bspapp.com/VKCEYUGU-a64ba7db-3cc1-47f2-a4a7-7ab09d13373b/7746ac27-59ab-4c78-82aa-898c9b9a4c6a.gif',
            url: url
        }, ]
    });
}






//按钮事件
function ButtonEvent(name) {

    //播放
    if (name == 'startplay') {
        //  	alert(JSON.stringify('播放'));
        //	moviePlayer.play();
    }


    //收藏
    if (name == 'Collection') {
        // 	alert(JSON.stringify('收藏'));

    }

    //升级会员
    if (name == 'sj') {
        //alert(JSON.stringify('升级会员'));

    }

    //分享
    //分享
    if (name == 'Share') {
        U.openWin('share/', 'share');
    }

    //H5播放器
    if (name == 'h5_paly') {
        console.log(xuan_url)
        U.openWin('browser/', 'webx5_jx_play_h5', {
            url: localStorage.getItem('jx_Interface_one') + xuan_url,
            primary_url: xuan_url,
            title: api.pageParam.title,
            cutlineNmae: '当前:默认线路'
        }, '');
        api.closeWin();
    }
    //投屏
    if (name == 'Touping') {
        U.OpenTouPingPopup(touping_video, api.pageParam.title);

    }


    //搜索设备
    if (name == 'SearchDevice') {
        //alert(JSON.stringify('开始检索可用投屏设备'));
        //开始检索可用投屏设备
        browse();

    }



}




/*音量检测*/
//type  1、提示    operation  操作



function VolumeInspect(type, operation) {

    //acc5Util 模块检测
    acc5Util.getVol({}, function(ret, err) {
        //  alert(JSON.stringify(ret.data['music']));

        //静音
        if (ret.data['music'] == 0) {

            if (type == 1) {

                mute_state.innerHTML = '手机可能处于静音状态';

                var obj = document.getElementById("mute_state");
                obj.setAttribute("class", 'aui-live-icon-em-mute');

                mute_state_touping.innerHTML = ' 手机静音中 停止后恢复';

                var obj = document.getElementById("mute_state_touping");
                obj.setAttribute("class", 'aui-live-icon-em-mute');



            }


            if (operation == 1) {

                //如果选择 自动调整音量
                if (localStorage.getItem('automatic_volume') == 1) {

                    acc5Util.setVol({
                        value: localStorage.getItem('default_player_volume')
                    }, function(ret, err) {})

                }

            }
        } else {


            //	mute_state.innerHTML = '开始追剧吧！';

            var obj = document.getElementById("mute_state");
            obj.setAttribute("class", 'aui-live-icon-em');


            mute_state_touping.innerHTML = ' 投屏时建议静音 ';

            var obj = document.getElementById("mute_state_touping");
            obj.setAttribute("class", 'aui-live-icon-em-mute-one');


        }
    })

}




/*** showTips提示方法 ***/
// 进行提示	showTips(提示消息,延迟时间, 1 关闭 空跳过,关闭后的消息,关闭延迟,1 警告 空跳过,警告消息,警告延迟,类型);
function showTips(msg, Timeout, isClose, CloseMsg, CloseTimeout, isWarning, WarningMsg, WarningTimeout, type) {

    if (type == 1) { // 视频提示信息

        var obj = document.getElementById("video_tip");
        obj.setAttribute("class", 'aui-live-header-black');
        video_tip.innerHTML = '<span style="font-size:12px;">' + msg + '</span>';

        //是否需要关闭
        //关闭 且 警告
        if (isClose == 1 && isWarning == 1) {

            setTimeout(function() { //延迟执行 警告

                var obj = document.getElementById("video_tip");
                obj.setAttribute("class", 'aui-live-header-warning');

                video_tip.innerHTML = '<span style="font-size:12px;">' + WarningMsg + '</span>'; //警告信息

                // setTimeout("closeTips()", WarningTimeout);  //延迟执行 关闭提示

                setTimeout(function() { //延迟执行 关闭

                    var obj = document.getElementById("video_tip");
                    obj.setAttribute("class", 'aui-live-header-close');

                    video_tip.innerHTML = '<span style="font-size:12px;">' + CloseMsg + '</span>'; //关闭后的信息

                }, CloseTimeout);

            }, WarningTimeout);



            //不关闭  但警告
        } else if (isWarning == 1) {

            setTimeout(function() { //延迟执行

                var obj = document.getElementById("video_tip");
                obj.setAttribute("class", 'aui-live-header-warning');

                video_tip.innerHTML = '<span style="font-size:12px;">' + WarningMsg + '</span>'; //警告信息

            }, Timeout);


            // 直接关闭 不警告
        } else if (isClose == 1) {

            setTimeout(function() { //延迟执行
                var obj = document.getElementById("video_tip");
                obj.setAttribute("class", 'aui-live-header-close');

                video_tip.innerHTML = '<span style="font-size:12px;">' + CloseMsg + '</span>'; //关闭后的信息

                //		video_operation_tip.innerHTML = '点击查看';

            }, Timeout);
        }
    } else if (type == 2) { // 投屏提示信息 Touping_tip
        var obj = document.getElementById("Touping_tip");
        obj.setAttribute("class", 'aui-live-touping-black');
        Touping_tip.innerHTML = '<span style="font-size:12px;">' + msg + '</span>';
        //是否需要关闭
        //关闭 且 警告
        if (isClose == 1 && isWarning == 1) {
            setTimeout(function() { //延迟执行 警告
                var obj = document.getElementById("Touping_tip");
                obj.setAttribute("class", 'aui-live-touping-warning');
                Touping_tip.innerHTML = '<span style="font-size:12px;">' + WarningMsg + '</span>'; //警告信息
                setTimeout(function() { //延迟执行 关闭
                    var obj = document.getElementById("Touping_tip");
                    obj.setAttribute("class", 'aui-live-touping-close');
                    Touping_tip.innerHTML = '<span style="font-size:12px;">' + CloseMsg + '</span>'; //关闭后的信息
                }, CloseTimeout);
            }, WarningTimeout);

            //不关闭  但警告
        } else if (isWarning == 1) {
            setTimeout(function() { //延迟执行
                var obj = document.getElementById("Touping_tip");
                obj.setAttribute("class", 'aui-live-touping-warning');
                Touping_tip.innerHTML = '<span style="font-size:12px;">' + WarningMsg + '</span>'; //警告信息
            }, Timeout);


            // 直接关闭 不警告
        } else if (isClose == 1) {

            setTimeout(function() { //延迟执行
                var obj = document.getElementById("Touping_tip");
                obj.setAttribute("class", 'aui-live-touping-close');
                Touping_tip.innerHTML = '<span style="font-size:12px;">' + CloseMsg + '</span>'; //关闭后的信息
            }, Timeout);
        }

    }

}
/*** showTips提示方法 ***/


//关闭解析浏览器
function CloseResolutionBrowser() {
    uzmoduledemo = api.require('androidBrowser');
    uzmoduledemo.closeView();
}


//换线
//关掉当前页面返回  X5
function OpenVideoJxPopup() {
    tinyPlayer.stop();
    // tinyPlayer.remove();
    U.OpenVideoJxAndroidPopup(xuan_url, api.pageParam.title, 1);
}



/*** 循环执行方法 ***/
// name   time   参数
function Recycling(name, time, param) {
    //定时检测音量
    var Task_number = name;
    var Task_number = setInterval(function() {
        eval(name + '("' + param + '");');
    }, time);

}
/*** 循环执行方法 ***/