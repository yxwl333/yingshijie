var touping;
var deviceIndex;
var acc5Util; //音量处理
var dkplayer;
var uzmoduledemo;
var Out_Time = 10000;
var Second_Out_Time = Out_Time / 1000;
var touping_video = null;
var xuan_url = '';
var getxuan;
var xuan_count = 0;

//定时检测音量
var interval = setInterval(function () {
    VolumeInspect(1);
}, 3000);


PlayerProcessingLogic = ''; //播放机处理状态
DeviceConnectionStatus = ''; //设备连接状态
ToupingProgressBarTips = 1; //投屏播放进度操作提示处理状态



apiready = function () {
    if (localStorage.getItem('is_play_change') == 0) {
        $api.byId('Mobile_player1').innerHTML = '';
    }
    xuan_url = api.pageParam.beginurl;
    console.log(xuan_url)
    api.parseTapmode();
    touping = api.require('touping');
    acc5Util = api.require('acc5Util');
    dkplayer = api.require('dkplayer');
    // goplay_dkplayer(); //播放器
    GoJiexi(api.pageParam.url, '默认线路');
    lmbrowse(); // 乐檬选集
    ad_img(); //乐檬广告

    //  GetData();
    // 	alert(JSON.stringify('传入值：'+api.pageParam.url));

    setTimeout(function () { //延迟执行
        //上传播放记录
        U.Up_Play_Record(api.pageParam.beginurl, api.pageParam.title);
    }, 10000);

    api.setScreenOrientation({
        orientation: 'portrait_up'
    });

    //监听播放状态
    dkplayer.addOnVideoViewStateChangeListener(function (ret, err) {
        //  alert(JSON.stringify(ret));
        if (ret.playState == 'STATE_ERROR') {
            U.toast('当前线路资源可能无法播放 请切换！');
            showTips('当前线路资源可能无法播放 请切换！ ', 10000, '', '', 10000, 1, '当前线路资源可能无法播放 请切换！', 10000, 1); //不关闭 只警告
        }
    });


    ///	 goplay();

    mute_state.innerHTML = api.pageParam.cutlineNmae;
    U.toast('正在努力为您获取资源 请稍等···');



    api.addEventListener({
        name: 'keyback'
    }, function (ret, err) {
        goback();
    });


    //换线
    api.addEventListener({
        name: 'cutline'
    }, function (ret, err) {
        var cutlineNmae = ret.value['cutlineNmae'];
        //	showTips('正在为您切换线路： '+ cutlineNmae ,5000,1,'',3000,'','',3000,1);			//只关闭 不警告
        showTips('正在为您切换线路： ' + cutlineNmae + '请稍等···', 5000, 1, '', 10000, 1, '如 ' + cutlineNmae + ' 无播放资源将维持当前播放线路', 3000, 1); //警告 并 关闭
        //	 alert(JSON.stringify('提交播放地址：'+api.pageParam.beginurl+'获取资源地址'));
        //先关闭解析窗口
        CloseResolutionBrowser();
        GoJiexi(ret.value['url'], cutlineNmae);
    });

    //离开页面时暂停播放
    api.addEventListener({
        name: 'viewdisappear'
    }, function () {
        //  moviePlayer.pause();
        goback();
    });


    //监听左上角返回
    api.addEventListener({
        name: 'goback'
    }, function () {
        //  moviePlayer.pause();
        goback();
    });

    //监听重新获取
    api.addEventListener({
        name: 'Exit_full_screen'
    }, function (ret, err) {
        if (ret) {

            goback();
            //dkplayer.release();

            // console.log('监听广播  退出全屏');

        }
    });


    showTips('影片中的文字广告请勿相信，谨防上当受骗！', 10000, 1, '', 10000, 1, '影片中的文字广告请勿相信，谨防上当受骗！', 10000, 1); //警告 并 关闭
    //	 showTips('影片中的文字广告请勿相信，谨防上当受骗！ ',5000,'','',3000,1,'影片中的文字广告请勿相信，谨防上当受骗',3000,1);			//不关闭 只警告
    // showTips('影片中的文字广告请勿相信，谨防上当受骗！ 长期驻留',5000,'','',3000,'','',3000,1);			//不关闭 不警告
    // showTips('影片中的文字广告请勿相信，谨防上当受骗！ 直接关闭 ',5000,1,'',3000,'','',3000,1);			//只关闭 不警告

    // showTips('','',1,'关闭后显示',3000,1,'警告后关闭','',1);			//警告 并 关闭






    /****事件检测****/
    api.addEventListener({
        name: 'pause'
    }, function (ret, err) {
        //alert('应用进入后台');
        dkplayer.pause();
    });


    api.addEventListener({
        name: 'resume'
    }, function (ret, err) {
        //alert('应用回到后台');
        // U.toast('正在为您恢复播放');
        dkplayer.resume();


    });

}

//加载结束
//乐檬选集
function lmbrowse() {
    console.log('开始加载选集：' + localStorage.getItem('api_url') + '/app/Lemon/?url=' + api.pageParam.beginurl);
    console.log(xuan_count);;
    api.ajax({
        url: localStorage.getItem('api_url') + '/app/Lemon/',
        method: 'get',
        data: {
            values: {
                url: api.pageParam.beginurl,
            }
        }
    }, function (ret, err) {
        getxuan = ret;
        console.log(JSON.stringify(getxuan))
        try {
            if (getxuan.code != 0) {
                console.log('接收到返回参数');
                var HTML = '';
                console.log('选集数量');
                if (getxuan.msg.length > 0) {
                    console.log('准备循环读取选集');
                    for (var i = 0; i < getxuan.msg.length; i++) {
                        var s = i + 1;
                        HTML += '<a  onclick="xuanji(' + '\'' + getxuan.msg[i].url + '\'' + ',' + s + ')" id="' + s + '" class="aui-palace-grid" style="background-color: #1b7dff;margin: 10px 2.5% 0 2.5%;"><div class="aui-palace-grid-text"><h2 style="color: #fff;">' + getxuan.msg[i].title + '</h2></div></a>';
                        isxuan = 1;
                    }
                    console.log('开始渲染');
                    var obj = document.getElementById("xuanji_title");
                    obj.setAttribute("class", 'aui-title display-block');
                    $api.byId('xuan_html_list_frm').innerHTML = HTML;
                    console.log('渲染结束');
                }
            }
        } catch (err) {
            // console.log(err);
            if (isxuan == 0 && xuan_count > 5) {
                xuan_count++;
                console.log('再次加载选集第' + xuan_count + '次')
                lmbrowse()
            }
        }

    });
}
//加载结束
//乐檬选集
function xuanji(url, id) {
    var HTML = '';
    for (var i = 0; i < getxuan.msg.length; i++) {
        var s = i + 1;
        HTML += '<a  onclick="xuanji(' + '\'' + getxuan.msg[i].url + '\'' + ',' + s + ')" id="' + s + '" class="aui-palace-grid" style="background-color: #1b7dff;margin: 10px 2.5% 0 2.5%;"><div class="aui-palace-grid-text"><h2 style="color: #fff;">' + getxuan.msg[i].title + '</h2></div></a>';
    }
    $api.byId('xuan_html_list_frm').innerHTML = HTML;
    var ids = document.getElementById(id);
    ids.style.backgroundColor = "#0450b5";
    api.toast({
        msg: '正在切换第' + id + '集请稍等',
        global: true
    });
    xuan_url = url;
    console.log(xuan_url)
    GoJiexi(localStorage.getItem('jx_Interface_one') + xuan_url, '选集播放');
}

// 乐檬广告
function ad_img() {
    var play_ad_img = localStorage.getItem('play_ad_img');
    if (play_ad_img != '') {
        list_img = '<img  onclick="ad_open(' + '\'' + localStorage.getItem('play_ad_url') + '\'' + ')" src="' + play_ad_img + '" alt="">'
        $api.byId('ad_img').innerHTML = list_img;
    }
}

function goback() {
    if (dkplayer.isFullScreen()) {
        if (dkplayer.isLock()) {
            api.toast({
                msg: '请先解锁屏幕！',
                global: true
            });
        } else {
            api.setScreenOrientation({
                orientation: 'portrait_up'
            });
            dkplayer.stopFullScreen();
        }
    } else {
        dkplayer.removeOnVideoViewStateChangeListener();
        dkplayer.release();
        api.closeWin();
    }
}


//播放器解析
function GoJiexis(url, line) {

    uzmoduledemo = api.require('androidBrowser');
    var param = {
        /*
        x:浏览器窗口X位置，默认0
        y:浏览器窗口y位置，默认0
        w:浏览器宽度，默认满屏
        h:浏览器高度，默认满屏
        */
        rect: {
            x: 0,
            y: 0,
            w: 1,
            h: 1,
        }, //w,h等于0代表横向满屏和纵向满屏
        fixedOn: "", //浏览器依附在哪个window,不传或传空 为 当前Window，默认当前当前Window
        fixed: true, //浏览器是否随frame或Window滑动，默认当前当前true
        url: url, //要加载的url,可选项
        browserBg: "#F0F0F0", //可选
        timeout: 7, //超时时间,指加载页面完毕后等待多少秒，超过这个时间还没收到视频地址，则认为解析视频地址失败。默认7秒

    };
    uzmoduledemo.openView(param, function (ret, err) {


        // console.log(JSON.stringify(ret));
        if (ret.result == '1') {

            console.log(JSON.stringify(ret));
            // 乐檬播放任意网站视频
            // arr = ret.VideoUrl.split('http');
            // console.log(JSON.stringify(arr));
            // // alert(JSON.stringify(ret));
            // for (var i = 0; i < arr.length; i++) {

            //     if (arr[i].indexOf("m3u8") != -1 || arr[i].indexOf("mp4") != -1) {
            //         video_url = 'http' + arr[i];
            //     }
            // }
            // console.log(video_url);  // true
            video_url = ret.VideoUrl;

            alert(JSON.stringify('解析成功：' + video_url));
            goplay_dkplayer(ret.VideoUrl);
            U.toast(line + ' 资源获取成功 准备播放');
            mute_state.innerHTML = line;
            touping_video = video_url;

            dkplayer.setUrl({
                url: video_url,
                title: api.pageParam.title,
                autoPlay: true
            });

            uzmoduledemo.closeView();

        }
    });

}

function GoJiexi(url, line) {

    uzmoduledemo = api.require('androidBrowser');
    var param = {
        /*
        x:浏览器窗口X位置，默认0
        y:浏览器窗口y位置，默认0
        w:浏览器宽度，默认满屏
        h:浏览器高度，默认满屏
        */
        rect: {
            x: 0,
            y: 0,
            w: 1,
            h: 1,
        }, //w,h等于0代表横向满屏和纵向满屏
        fixedOn: "", //浏览器依附在哪个window,不传或传空 为 当前Window，默认当前当前Window
        fixed: true, //浏览器是否随frame或Window滑动，默认当前当前true
        url: url, //要加载的url,可选项
        browserBg: "#F0F0F0", //可选
        timeout: 7, //超时时间,指加载页面完毕后等待多少秒，超过这个时间还没收到视频地址，则认为解析视频地址失败。默认7秒

    };
    uzmoduledemo.openView(param, function (ret, err) {

        console.log(JSON.stringify(ret));

        //			alert(JSON.stringify(ret));

        if (ret.result == '1') {
            video_url = ret.VideoUrl;

            //		alert(JSON.stringify('解析成功：'+video_url));
            goplay_dkplayer(ret.VideoUrl);
            U.toast(line + ' 资源获取成功 准备播放');
            mute_state.innerHTML = line;
            touping_video = video_url;

            // dkplayer.setUrl({
            //     url: video_url,
            //     title: api.pageParam.title,
            //     autoPlay: true
            // });

            uzmoduledemo.closeView();

        }
    });



}


function viodeplay() {

    GoJiexiH5(localStorage.getItem('jx_Interface_one') + xuan_url, '系统播放器');
}


function GoJiexiH5(url, line) {
    uzmoduledemo = api.require('androidBrowser');
    //	alert(JSON.stringify(url));
    var param = {
        rect: {
            x: 0,
            y: 0,
            w: 1,
            h: 1,
        }, //w,h等于0代表横向满屏和纵向满屏
        fixedOn: "", //浏览器依附在哪个window,不传或传空 为 当前Window，默认当前当前Window
        fixed: true, //浏览器是否随frame或Window滑动，默认当前当前true
        url: url, //要加载的url,可选项
        browserBg: "#F0F0F0", //可选
        timeout: 7, //超时时间,指加载页面完毕后等待多少秒，超过这个时间还没收到视频地址，则认为解析视频地址失败。默认7秒

    };
    uzmoduledemo.openView(param, function (ret, err) {

        console.log(JSON.stringify(ret));
        //开始loading加载
        // api.showProgress({
        //     title: '请稍等...',
        //     text: '正在调用系统播放器打开视频',
        // });
        U.toast(' 正在调用系统播放器打开视频');
        // alert(JSON.stringify(ret));

        if (ret.result == '1') {
            // 乐檬播放任意网站视频
            arr = ret.VideoUrl.split('http');
            console.log(JSON.stringify(arr));
            for (var i = 0; i < arr.length; i++) {
                if (arr[i].indexOf("m3u8") != -1 || arr[i].indexOf("mp4") != -1) {
                    video_url = 'http' + arr[i];
                }
            }
            console.log(video_url); // true
            // video_url = ret.VideoUrl;
            U.toast(line + ' 资源获取成功 准备播放');

            touping_video = video_url;
            //弹出状态栏通知
            //结束loading
            api.hideProgress();
            api.notification({
                notify: {
                    title: '调用系统播放器打开视频',
                    content: video_url
                }
            });
            //打开系统视频播放器

            api.openVideo({
                url: video_url
            });





            uzmoduledemo.closeView();

        }
    });



}


// 准备投屏	 url传入地址    num 传入集数
function goTouping() {
    browse();
    //如果 投屏设备连接状态 已经连接
    if (DeviceConnectionStatus == 1) {
        //进行提示
        showTips('<svg t="1570042262883" class="deviceListmaincate_nav_ico" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="35759" width="64" height="64"><path d="M170.666667 682.666667h85.333333a42.666667 42.666667 0 0 1 0 85.333333H128a42.666667 42.666667 0 0 1-42.666667-42.666667V213.333333a42.666667 42.666667 0 0 1 42.666667-42.666666h768a42.666667 42.666667 0 0 1 42.666667 42.666666v512a42.666667 42.666667 0 0 1-42.666667 42.666667h-128a42.666667 42.666667 0 0 1 0-85.333333h85.333333V256H170.666667v426.666667z m243.498666 158.165333a42.666667 42.666667 0 1 1-60.330666-60.330667l128-128a42.666667 42.666667 0 0 1 60.330666 0l128 128a42.666667 42.666667 0 0 1-60.330666 60.330667L512 742.997333l-97.834667 97.834667z" p-id="35760" fill="#8f99ad"></path></svg> 正在为您投屏播放 ' + num + ' 集', 10000, '', '关闭后显示', 2000, '', '', '', 1); //警告 并 关闭
        //改变正在播放集数的样式
        //		changeNumberStatus('di'+num+'ji');
        //提交解析接口   TYPE 2 投屏
        //		gojiexi(url,2);
        //投屏

        play(api.pageParam.url);
        //如果 投屏设备连接状态 未连接
    } else {
        //进行提示
        showTips('', '', '', '', 2000, 1, '请先搜索设备并连接', 3000, 2); //不关闭 只警告
        //开始检索可用投屏设备
        browse();
    }


}




// 打开播放器播放
function goplay_dkplayer(url) {
    dkplayer.open({
        rect: {
            x: 0,
            y: 0,
            w: 0,
            h: 250
        },
        url: url,
        coverImg: '../../images/loading.jpg',
        animation: false,
        title: api.pageParam.title,
        isLive: false,
        enableFull: false, //是否全屏
        autoPlay: true, //自动播放  false
        fixedOn: api.frameName,
        fixed: true
    }, function (ret, err) {


        /*
                //播放状态监测
                      dkplayer.addOnVideoViewStateChangeListener(function(ret, err) {
                        // 取值范围：
                       //STATE_IDLE，静止状态，此时播放器还未进行初始化
                       //STATE_PREPARING，正在准备播放
                       //STATE_PREPARED，准备完成状态
                       //STATE_PLAYING，正在播放状态
                       //STATE_PAUSED，暂停播放状态
                       //STATE_BUFFERING，缓冲状态
                       //STATE_BUFFERED，缓冲结束状态
                       //STATE_PLAYBACK_COMPLETED，播放结束状态
                       //STATE_ERROR，播放错误
                    ///        if(playState == 'STATE_ERROR'){
                              //  alert(JSON.stringify('播放错误  开始重获取'));
                    ///            U.Jx_androidBrowser(api.pageParam.url);
                  ///          }
    	
    	
    	
                          alert(JSON.stringify(ret));
                      });
        */

        //    alert(JSON.stringify(ret));
    });
}







//按钮事件
function ButtonEvent(name) {

    //播放
    if (name == 'startplay') {
        //  	alert(JSON.stringify('播放'));
        //	moviePlayer.play();
    }


    //收藏
    if (name == 'Collection') {
        // 	alert(JSON.stringify('收藏'));

    }

    //升级会员
    if (name == 'sj') {
        //alert(JSON.stringify('升级会员'));

    }

    //分享
    //分享
    if (name == 'Share') {
        // alert(JSON.stringify('分享'));
        // OpenVideoJxPopup();
        // U.openWin('browser/', 'webbrowser2018_jx_play', { url: api.pageParam.url, beginurl: api.pageParam.beginurl, title: api.pageParam.title, cutlineNmae: '当前:默认线路' }, '');
        U.openWin('share/', 'share');

    }

    //H5播放器
    if (name == 'h5_paly') {
        // alert(JSON.stringify('分享'));
        // OpenVideoJxPopup();
        console.log(xuan_url)
        // U.openWin('browser/', 'webx5_jx_play_h5', { url: 'https://jx.parwix.com:4433/player/analysis.php?v=https://v.qq.com/x/cover/rjae621myqca41h/i0032qxbi2v.html', primary_url: 'https://v.qq.com/x/cover/rjae621myqca41h/i0032qxbi2v.html', title:'VIP', cutlineNmae: '当前:默认线路' }, '');
        U.openWin('browser/', 'webx5_jx_play_h5', {
            url: localStorage.getItem('jx_Interface_one') + xuan_url,
            primary_url: xuan_url,
            title: api.pageParam.title,
            cutlineNmae: '当前:默认线路'
        }, '');

    }


    //投屏
    if (name == 'Touping') {

        browse();

        //alert(JSON.stringify('投屏'));
        var obj = document.getElementById("Tv_player");
        obj.setAttribute("class", 'display-block');

        var obj = document.getElementById("Mobile_player");
        obj.setAttribute("class", 'display-none');

        var obj = document.getElementById("Mobile_player1");
        obj.setAttribute("class", 'display-none');

        // var obj = document.getElementById("maincate_nav");
        // obj.setAttribute("class", 'deviceListmaincate_touping_nav');

        // var obj = document.getElementById("maincate_touping_list");
        // obj.setAttribute("class", 'deviceListmaincate display-block');

        // var obj = document.getElementById("maincate");
        // obj.setAttribute("class", 'maincate display-none');


        //如果选择 自动调整音量
        if (localStorage.getItem('automatic_volume') == 1) {

            acc5Util.setVol({
                value: 0
            }, function (ret, err) {
                //	alert(JSON.stringify(ret));

            })

        }





    }


    //搜索设备
    if (name == 'SearchDevice') {
        //alert(JSON.stringify('开始检索可用投屏设备'));
        //开始检索可用投屏设备
        browse();

    }


    //开始投屏
    if (name == 'StartTouping') {
        //开始投屏
        //	play();
        var touping_url = touping_video;
        //alert(JSON.stringify(touping_url ));
        //	play(touping_url);
        playUrl(touping_url);
    }


    //停止投屏
    if (name == 'CloseTouping') {

        //	alert(JSON.stringify('停止投屏'));
        //停止投屏
        stop();


        var obj = document.getElementById("Tv_player");
        obj.setAttribute("class", 'display-none');

        var obj = document.getElementById("Mobile_player");
        obj.setAttribute("class", 'display-block');

        var obj = document.getElementById("Mobile_player1");
        obj.setAttribute("class", 'display-block');

        // var obj = document.getElementById("maincate");
        // obj.setAttribute("class", 'maincate display-block');

        // var obj = document.getElementById("maincate_touping_list");
        // obj.setAttribute("class", 'deviceListmaincate display-none');

        // var obj = document.getElementById("maincate_nav");
        // obj.setAttribute("class", 'maincate_nav');


        //如果选择 自动调整音量
        if (localStorage.getItem('automatic_volume') == 1) {

            acc5Util.setVol({
                value: localStorage.getItem('default_player_volume')
            }, function (ret, err) {
                //	alert(JSON.stringify(ret));
                //		api.toast({
                //		msg: '音量调整为'+localStorage.getItem('default_player_volume'),
                //		duration: 2000,
                //		location : 'middle'
                //	});
            })

        }

        //播放器显示
        // moviePlayer.show();
        //播放器开始播放
        //	moviePlayer.play();

    }

}




/*音量检测*/
//type  1、提示    operation  操作



function VolumeInspect(type, operation) {

    //acc5Util 模块检测
    acc5Util.getVol({}, function (ret, err) {
        //  alert(JSON.stringify(ret.data['music']));

        //静音
        if (ret.data['music'] == 0) {

            if (type == 1) {

                mute_state.innerHTML = '手机可能处于静音状态';

                var obj = document.getElementById("mute_state");
                obj.setAttribute("class", 'aui-live-icon-em-mute');

                mute_state_touping.innerHTML = ' 手机静音中 停止后恢复';

                var obj = document.getElementById("mute_state_touping");
                obj.setAttribute("class", 'aui-live-icon-em-mute');



            }


            if (operation == 1) {

                //如果选择 自动调整音量
                if (localStorage.getItem('automatic_volume') == 1) {

                    acc5Util.setVol({
                        value: localStorage.getItem('default_player_volume')
                    }, function (ret, err) {
                        //	alert(JSON.stringify(ret));
                        //		api.toast({
                        //		msg: '音量调整为'+localStorage.getItem('default_player_volume'),
                        //		duration: 2000,
                        //		location : 'middle'
                        //	});
                    })

                }

            }

            /*
                    api.toast({
                        msg: '手机处于静音状态',
                        duration: 2000,
                        location : 'middle'
                    });

                */


        } else {


            //	mute_state.innerHTML = '开始追剧吧！';

            var obj = document.getElementById("mute_state");
            obj.setAttribute("class", 'aui-live-icon-em');


            mute_state_touping.innerHTML = ' 投屏时建议静音 ';

            var obj = document.getElementById("mute_state_touping");
            obj.setAttribute("class", 'aui-live-icon-em-mute-one');

            /*
                        api.toast({
                            msg: '声音正常',
                            duration: 2000,
                            location : 'middle'
                        });

            */

        }
    })

}

/*投屏模块*/
function browse() {
    $api.byId('deviceList').innerHTML = '';
    touping.browse(function (ret, err) {
        if (ret.status) {
            showDeviceList(ret.deviceList);
            //	alert(JSON.stringify(ret));

            // document.getElementById("tips").textContent = "搜索到" + ret.deviceList.length + "个设备，请选择要投屏的设备";

            //	showTips('正在搜索可用设备…',5000,'','',3000,1,'搜索到'+ret.deviceList.length+'个设备，请选择要投屏的设备',3000,2);			//不关闭 只警告
            //	showTips('','',1,'正在搜索可用设备…',3000,1,'搜索到'+ret.deviceList.length+'个设备，请选择要投屏的设备','',2);			//警告 并 关闭
            showTips('正在搜索可用设备 ··· ', 1000, 1, '搜索到' + ret.deviceList.length + '个设备，请选择投屏接收设备', 3000, '', '', 3000, 2); //只关闭 不警告
            var obj = document.getElementById("Touping_deviceList");
            obj.setAttribute("class", 'deviceListmaincate_nav display-block');


        } else {

            //  document.getElementById("tips").textContent = "未搜索到设备，请检查当前局域网内是否有可投屏设备";
            //	showTips('未搜索到设备，请检查当前局域网内是否有可投屏设备',5000,1,'关闭后显示内容',3000,1,'警告后关闭',3000);			//警告 并 关闭
            showTips('正在搜索可用设备 ···', 3000, '', '', 3000, 1, '未搜索到设备，请检查当前局域网内是否有可投屏设备', 3000, 2); //不关闭 只警告
        }
    });
}

//显示设备名
function showDeviceList(deviceList) {

    for (var i = 0; i < deviceList.length; i++) {
        var item = '<a onclick="choiceDevice(&quot;' + deviceList[i].name + '&quot;,' + i + ')"> ' + deviceList[i].name + '</a>';
        $api.byId('deviceList').insertAdjacentHTML('beforeEnd', item);
    }
}

function choiceDevice(name, index) {
    deviceIndex = index;
    //   document.getElementById("tips").textContent = "您选择了 " + name + " 进行投屏";

    showTips('正在连接设备 ···', 1000, 1, '<svg t="1570083742316" class="deviceListmaincate_nav_ico" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="7496" width="64" height="64"><path d="M512 149.965c-199.947 0-380.965 81.039-511.994 212.077l96.02 96.019C202.474 351.582 349.542 285.723 512 285.723s309.526 65.859 415.975 172.338l96.02-96.019C892.965 231.004 711.947 149.965 512 149.965z" p-id="7497" fill="#222222"></path><path d="M160.004 522.05l95.979 95.989C321.512 552.51 412.021 512 512 512s190.487 40.51 256.017 106.039l95.979-95.989C773.917 431.951 649.458 376.242 512 376.242c-137.459 0-261.896 55.709-351.996 145.808z" p-id="7498" fill="#222222"></path><path d="M320.002 682.038L512 874.035l191.998-191.997c-49.13-49.14-117.02-79.529-191.998-79.529s-142.868 30.389-191.998 79.529z" p-id="7499" fill="#222222"></path></svg>' + name + ' 连接成功！可以进行投屏播放', 3000, '', '', 3000, 2); //只关闭 不警告
    //投屏设备连接状态 已经连接
    DeviceConnectionStatus = 1;

    var obj = document.getElementById("Touping_deviceList");
    obj.setAttribute("class", 'deviceListmaincate_nav display-none');

}

function play(url) {
    touping.play({
        index: deviceIndex,
        url: url
    }, function (ret, err) {
        //   alert(JSON.stringify(ret));
        if (ret.result == false) {
            playUrl(url);
        }
    });
}

function playUrl(url) {
    touping.playUrl({
        url: url
    }, function (ret, err) {

        //   alert(JSON.stringify(ret));
        if (ret.result == false) {
            play(url);
        }
        //   if(ret.result == true){
        //		showTips('正在为您投屏播放 '+num+' 集',10000,'','关闭后显示',2000,'','','',1);			//警告 并 关闭
        //   }

    });

}

function stop() {
    touping.stop(function (ret, err) {
        // alert(JSON.stringify(err));

        if (ret.result == true) {
            showTips('', '', 1, '', 3000, 1, '已停止投屏', '', 1); //警告 并 关闭
        }

    });
}

function volume(value) {
    touping.volume({
        value: value
    }, function (ret, err) {
        // console.log(JSON.stringify(ret));
    });
}

function seek(value) {
    touping.seek({
        value: value
    }, function (ret, err) {
        // console.log(JSON.stringify(ret));
        //   alert(JSON.stringify(ret));

        api.toast({
            msg: value,
            duration: 2000,
            location: 'middle'
        });


    });

}


/*** showTips提示方法 ***/
// 进行提示	showTips(提示消息,延迟时间, 1 关闭 空跳过,关闭后的消息,关闭延迟,1 警告 空跳过,警告消息,警告延迟,类型);
function showTips(msg, Timeout, isClose, CloseMsg, CloseTimeout, isWarning, WarningMsg, WarningTimeout, type) {

    if (type == 1) { // 视频提示信息

        var obj = document.getElementById("video_tip");
        obj.setAttribute("class", 'aui-live-header-black');


        video_tip.innerHTML = '<span style="font-size:10px;">' + msg + '</span>';

        //有延迟时间
        /*		if(Timeout > 0){
                        setTimeout(function() {

                            api.refreshHeaderLoadDone()

                        }, Timeout);
                }else{

                }
        */


        //是否需要关闭
        //关闭 且 警告
        if (isClose == 1 && isWarning == 1) {

            setTimeout(function () { //延迟执行 警告

                var obj = document.getElementById("video_tip");
                obj.setAttribute("class", 'aui-live-header-warning');

                video_tip.innerHTML = '<span style="font-size:10px;">' + WarningMsg + '</span>'; //警告信息

                // setTimeout("closeTips()", WarningTimeout);  //延迟执行 关闭提示

                setTimeout(function () { //延迟执行 关闭

                    var obj = document.getElementById("video_tip");
                    obj.setAttribute("class", 'aui-live-header-close');

                    video_tip.innerHTML = '<span style="font-size:10px;">' + CloseMsg + '</span>'; //关闭后的信息

                    //			video_operation_tip.innerHTML = '点击切换播放模式';

                }, CloseTimeout);

                //		video_operation_tip.innerHTML = '提示即将关闭';


            }, WarningTimeout);



            //不关闭  但警告
        } else if (isWarning == 1) {

            setTimeout(function () { //延迟执行

                var obj = document.getElementById("video_tip");
                obj.setAttribute("class", 'aui-live-header-warning');

                video_tip.innerHTML = '<span style="font-size:10px;">' + WarningMsg + '</span>'; //警告信息

            }, Timeout);


            // 直接关闭 不警告
        } else if (isClose == 1) {

            setTimeout(function () { //延迟执行
                var obj = document.getElementById("video_tip");
                obj.setAttribute("class", 'aui-live-header-close');

                video_tip.innerHTML = '<span style="font-size:10px;">' + CloseMsg + '</span>'; //关闭后的信息

                //		video_operation_tip.innerHTML = '点击查看';

            }, Timeout);
        }



    } else if (type == 2) { // 投屏提示信息 Touping_tip



        var obj = document.getElementById("Touping_tip");
        obj.setAttribute("class", 'aui-live-touping-black');


        Touping_tip.innerHTML = '<span style="font-size:10px;">' + msg + '</span>';

        //有延迟时间
        /*		if(Timeout > 0){
                        setTimeout(function() {

                            api.refreshHeaderLoadDone()

                        }, Timeout);
                }else{

                }
        */


        //是否需要关闭
        //关闭 且 警告
        if (isClose == 1 && isWarning == 1) {

            setTimeout(function () { //延迟执行 警告

                var obj = document.getElementById("Touping_tip");
                obj.setAttribute("class", 'aui-live-touping-warning');

                Touping_tip.innerHTML = '<span style="font-size:10px;">' + WarningMsg + '</span>'; //警告信息

                // setTimeout("closeTips()", WarningTimeout);  //延迟执行 关闭提示

                setTimeout(function () { //延迟执行 关闭

                    var obj = document.getElementById("Touping_tip");
                    obj.setAttribute("class", 'aui-live-touping-close');

                    Touping_tip.innerHTML = '<span style="font-size:10px;">' + CloseMsg + '</span>'; //关闭后的信息

                    //			video_operation_tip.innerHTML = '点击查看';

                }, CloseTimeout);

                //			video_operation_tip.innerHTML = '提示即将关闭';


            }, WarningTimeout);



            //不关闭  但警告
        } else if (isWarning == 1) {

            setTimeout(function () { //延迟执行

                var obj = document.getElementById("Touping_tip");
                obj.setAttribute("class", 'aui-live-touping-warning');

                Touping_tip.innerHTML = '<span style="font-size:10px;">' + WarningMsg + '</span>'; //警告信息

            }, Timeout);


            // 直接关闭 不警告
        } else if (isClose == 1) {

            setTimeout(function () { //延迟执行
                var obj = document.getElementById("Touping_tip");
                obj.setAttribute("class", 'aui-live-touping-close');

                Touping_tip.innerHTML = '<span style="font-size:10px;">' + CloseMsg + '</span>'; //关闭后的信息

                //			video_operation_tip.innerHTML = '点击查看';

            }, Timeout);
        }







    }

}
/*** showTips提示方法 ***/


//关闭解析浏览器
function CloseResolutionBrowser() {
    uzmoduledemo.closeView();
}


//换线
//关掉当前页面返回  X5
function OpenVideoJxPopup() {
    //  moviePlayer.pause();
    //		U.OpenVideoJxPopup(localStorage.getItem('Play_url'),0);

    U.OpenVideoJxAndroidPopup(xuan_url, api.pageParam.title, 1);
    // U.OpenVideoJxAndroidPopup(api.pageParam.beginurl, api.pageParam.title, 1);
    /*
    //广播打开 接口列表
    api.sendEvent({
        name: 'cutline',		//广播更新用户数据
        extra: {
                url:api.pageParam.url,
                type: api.pageParam.title
        }
    });


        U.closeWin('videos_play_jiexi');
*/

    //   moviePlayer.close();

    //	U.OpenVideoJxPopup(api.pageParam.initialurl);
}





/*** 循环执行方法 ***/
// name   time   参数
function Recycling(name, time, param) {
    //定时检测音量
    var Task_number = name;
    var Task_number = setInterval(function () {

        //不带参数
        //	 eval(name+'();');
        //有参
        eval(name + '("' + param + '");');

    }, time);

}
/*** 循环执行方法 ***/