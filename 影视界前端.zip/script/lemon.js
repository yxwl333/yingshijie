var xuan_url = '';
var getxuan;

function lmbrowse() {
    //乐檬选集
    console.log('开始加载选集')
    api.ajax({
        url: localStorage.getItem('api_url') + '/app/Lemon/',
        method: 'get',
        data: {
            values: {
                url: api.pageParam.beginurl,
            }
        }
    }, function (ret, err) {
        getxuan = ret;
        if (getxuan.code != 0) {
            var HTML = '';
            for (var i = 0; i < ret.msg.length; i++) {
                var s = i + 1;
                HTML += '<a  onclick="xuanji(' + '\'' + getxuan.msg[i].url + '\'' + ',' + s + ')" id="' + s + '" class="aui-palace-grid" style="background-color: #1b7dff;margin: 10px 2.5% 0 2.5%;"><div class="aui-palace-grid-text"><h2 style="color: #fff;">' + getxuan.msg[i].title + '</h2></div></a>';
            }
            $api.byId('xuan_html_list_frm').innerHTML = HTML;
            // $api.append(xuan_html_list_frm, HTML);
        }
    });
}
//乐檬选集
function xuanji(url, id) {
    var HTML = '';
    for (var i = 0; i < getxuan.msg.length; i++) {
        var s = i + 1;
        HTML += '<a  onclick="xuanji(' + '\'' + getxuan.msg[i].url + '\'' + ',' + s + ')" id="' + s + '" class="aui-palace-grid" style="background-color: #1b7dff;margin: 10px 2.5% 0 2.5%;"><div class="aui-palace-grid-text"><h2 style="color: #fff;">' + getxuan.msg[i].title + '</h2></div></a>';
    }
    $api.byId('xuan_html_list_frm').innerHTML = HTML;
    var ids = document.getElementById(id);
    ids.style.backgroundColor = "#0450b5";
    api.toast({
        msg: '正在切换第' + id + '集请稍等',
        global: true
    });
    xuan_url = url;
    console.log(xuan_url)
    GoJiexi(localStorage.getItem('jx_Interface_one') + xuan_url, '选集播放');
}